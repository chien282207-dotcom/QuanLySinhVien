package model;

public class Diem {
    private String maSV;
    private String maMH;
    private double diemQuaTrinh;
    private double diemThi;

    public Diem() {}

    public Diem(String maSV, String maMH, double diemQuaTrinh, double diemThi) {
        this.maSV = maSV;
        this.maMH = maMH;
        this.diemQuaTrinh = diemQuaTrinh;
        this.diemThi = diemThi;
    }

    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public String getMaMH() { return maMH; }
    public void setMaMH(String maMH) { this.maMH = maMH; }
    public double getDiemQuaTrinh() { return diemQuaTrinh; }
    public void setDiemQuaTrinh(double diemQuaTrinh) { this.diemQuaTrinh = diemQuaTrinh; }
    public double getDiemThi() { return diemThi; }
    public void setDiemThi(double diemThi) { this.diemThi = diemThi; }
    public double getDiemTrungBinh() { return Math.round((diemQuaTrinh * 0.4 + diemThi * 0.6) * 100.0) / 100.0; }
}
