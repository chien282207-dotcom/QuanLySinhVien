package model;

public class Lop {
    private String maLop;
    private String tenLop;
    private String nganhHoc;

    public Lop() {}

    public Lop(String maLop, String tenLop, String nganhHoc) {
        this.maLop = maLop;
        this.tenLop = tenLop;
        this.nganhHoc = nganhHoc;
    }

    public String getMaLop() { return maLop; }
    public void setMaLop(String maLop) { this.maLop = maLop; }
    public String getTenLop() { return tenLop; }
    public void setTenLop(String tenLop) { this.tenLop = tenLop; }
    public String getNganhHoc() { return nganhHoc; }
    public void setNganhHoc(String nganhHoc) { this.nganhHoc = nganhHoc; }
}
