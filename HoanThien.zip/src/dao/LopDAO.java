package dao;

import config.DatabaseConnection;
import model.Lop;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LopDAO {
    public List<Lop> getAllLop() {
        List<Lop> list = new ArrayList<>();
        String sql = "SELECT * FROM Lop";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Lop(
                    rs.getString("MaLop"),
                    rs.getString("TenLop"),
                    rs.getString("NganhHoc")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean insertLop(Lop l) {
        String sql = "INSERT INTO Lop VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, l.getMaLop());
            ps.setString(2, l.getTenLop());
            ps.setString(3, l.getNganhHoc());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateLop(Lop l) {
        String sql = "UPDATE Lop SET TenLop=?, NganhHoc=? WHERE MaLop=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, l.getTenLop());
            ps.setString(2, l.getNganhHoc());
            ps.setString(3, l.getMaLop());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteLop(String maLop) {
        String sql = "DELETE FROM Lop WHERE MaLop=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maLop);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Lop> searchLop(String keyword) {
        List<Lop> list = new ArrayList<>();
        String sql = "SELECT * FROM Lop WHERE MaLop LIKE ? OR TenLop LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Lop(
                    rs.getString("MaLop"),
                    rs.getString("TenLop"),
                    rs.getString("NganhHoc")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
