package dao;

import config.DatabaseConnection;
import model.Diem;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DiemDAO {
    public List<Diem> getAllDiem() {
        List<Diem> list = new ArrayList<>();
        String sql = "SELECT * FROM Diem";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Diem(
                    rs.getString("MaSV"),
                    rs.getString("MaMH"),
                    rs.getDouble("DiemQuaTrinh"),
                    rs.getDouble("DiemThi")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean insertDiem(Diem d) {
        String sql = "INSERT INTO Diem VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, d.getMaSV());
            ps.setString(2, d.getMaMH());
            ps.setDouble(3, d.getDiemQuaTrinh());
            ps.setDouble(4, d.getDiemThi());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateDiem(Diem d) {
        String sql = "UPDATE Diem SET DiemQuaTrinh=?, DiemThi=? WHERE MaSV=? AND MaMH=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDouble(1, d.getDiemQuaTrinh());
            ps.setDouble(2, d.getDiemThi());
            ps.setString(3, d.getMaSV());
            ps.setString(4, d.getMaMH());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteDiem(String maSV, String maMH) {
        String sql = "DELETE FROM Diem WHERE MaSV=? AND MaMH=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maSV);
            ps.setString(2, maMH);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Diem> searchDiemByMaSV(String maSV) {
        List<Diem> list = new ArrayList<>();
        String sql = "SELECT * FROM Diem WHERE MaSV LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + maSV + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Diem(
                    rs.getString("MaSV"),
                    rs.getString("MaMH"),
                    rs.getDouble("DiemQuaTrinh"),
                    rs.getDouble("DiemThi")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
